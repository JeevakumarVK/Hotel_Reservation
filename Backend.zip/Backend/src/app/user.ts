export class User {

  name!:string;
  userId!:string;
  email!:string;
  phone!:string;
  password!:string;
  cpassword!:string;
  gender!:string;
}
