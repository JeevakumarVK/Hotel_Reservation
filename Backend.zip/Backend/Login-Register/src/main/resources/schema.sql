create table users(
id bigint primary key,
username varchar(225),
password varchar(225),
role varchar(225)
);